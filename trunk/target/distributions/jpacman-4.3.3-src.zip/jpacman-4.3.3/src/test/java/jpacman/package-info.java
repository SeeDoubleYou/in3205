/**
  * This package contains the top level unit test suite,
  * test utilities, and the acceptance test suite.
  *
  * @author Arie van Deursen
  * @version $Id: package-info.java,v 1.1 2008/02/10 19:46:31 arie Exp $
  *
  *
  */
package jpacman;
